class Contato {
  final int id;
  final String nome;
  final String frase;
  final String telefone;
  final String urlImage;

  Contato(this.id, this.nome, this.frase, this.telefone, this.urlImage);
}
